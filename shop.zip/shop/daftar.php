<?php
   session_start();
   if(isset($_SESSION['id_pembeli'])) {
   header(''); }
   require_once("koneksi.php");
?>
<!doctype html>
<html>
<head>
<title>Pendaftaran Pembeli</title>
<style>
*{
    margin: 0;
    padding: 0;
    outline: 0;
    font-family: 'PT Serif';
}
body{
    height: 100vh;
    background-image: url();
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}

.container{
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    padding: 20px 25px;
    width: 300px;

    background-color: rgba(0,0,0,.7);
    box-shadow: 0 0 10px rgba(255,255,255,.3);
}
.container h2{
    text-align: Center;
	border: none;
    color: #fafafa;
	border-bottom: 3px solid #2979ff;
    margin-bottom: 40px;
}
.container h4{
    text-align: Center;
    color: #fafafa;
    margin-bottom: 30px;
}
.container input{
	text-align: Center;
    margin-bottom: 30px;
}
.container h5{
    text-align: Center;
    color: #fafafa;
    margin-bottom: 20px;
	font-size: 15px;
}
.container label{
    text-align: left;
    color: #90caf9;
}
.container form input{
    width: calc(100% - 20px);
    padding: 8px 10px;
    margin-bottom: 10px;
    border: none;
    background-color: transparent;
    border-bottom: 2px solid #2979ff;
    color: #fff;
    font-size: 20px;
}
.container form button{
    width: 100%;
    padding: 5px 0;
    border: none;
    background-color:#2979ff;
    font-size: 18px;
    color: #fafafa;
	margin-bottom: 20px;
}
</style>
</head>

<BODY STYLE="BACKGROUND-IMAGE:URL(admin/bg.png)">
<section class="popup-graybox">
<div class="container">
<form role="form" action="cekdaftar.php" method="post">
  <h2 data-edit="text">Daftar Akun</h2>
  <div class="ebook-email-sec">
 	<br><input autocomplete="off" name="nama" type="text" class="form-control" placeholder="Masukkan Nama Lengkap"> </br>
	<br><input autocomplete="off" name="alamat" type="text" class="form-control" placeholder="Masukkan Alamat"></br>
	<br><input autocomplete="off" name="no_tlp" type="text	" class="form-control" placeholder="Masukan No. Tlp"></br>
	<br><input autocomplete="off" name="email" type="text" class="form-control" placeholder="Masukkan Email"></br>
    <br><input name="pass" type="password" class="form-control" placeholder="Masukkan Password"></br>
<BR>
    <button class="ebook-input-btn" type="submit" name="Submit">Submit</button>
</BR>
  </div>
  <div>
  <h5>Sudah Punya Akun? <span><a href="login.php"> Login Disini </span> </h5>
</div>    
</section>
</form>

</body>
</html>
