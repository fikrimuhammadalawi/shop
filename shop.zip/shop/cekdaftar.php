<?php
   require_once("/admin/koneksi.php");
   $email = $_POST['email'];
   $password = $_POST['pass'];
   $nama = $_POST['nama'];
   $alamat = $_POST['alamat'];
   $tlp = $_POST['no_tlp'];
   $sql = "SELECT * FROM pembeli WHERE id_pembeli = '$email'";
   $query = $koneksi->query($sql);
   if($query->num_rows != 0) {
     echo "<div align='center'><h1>Username Sudah Terdaftar! <a href='daftar.php'>Back?</a></div>";
   } else {
     if(!$nama || !$alamat ||!$tlp ||!$email ||!$password) {
       echo "<div align='center'><h1>Masih ada data yang kosong!</h1> <a href='daftar.php'>Back?</a>";
     } else {
       $data = "INSERT INTO id_pembeli VALUES ('$nama', '$alamat', '$tlp', '$email','$password')";
       $simpan = $koneksi->query($data);
       if($simpan) {
         echo "<div align='center'><h1>Pendaftaran Sukses, Silahkan <a href='login.php'>Login</h1></a></div>";
       } else {
         echo "<div align='center'><h1>Proses Gagal! Silahkan Daftar Kembali</h1></div>";
       }
     }
   }
?>