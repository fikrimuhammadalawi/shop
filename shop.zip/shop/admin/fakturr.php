<?php $koneksi=new mysqli("localhost","root","","toko_parfume");
session_start();
?>


<!DOCTYPE html>
<html>
<head>
	<title> Faktur </title>
	<link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>
<BODY STYLE="BACKGROUND-IMAGE:URL(faktur.JPG)">



<?php include 'menu.php'?>

<section class="konten>
	<div class="container"> 
	
	
	
	<h3> Faktur </h3>
<?php 
$ambil= $koneksi->query("SELECT * FROM faktur JOIN pembeli 
						ON faktur.id_pembeli=pembeli.id_pembeli
						WHERE faktur.id_faktur='$_GET[id]'");
$detail = $ambil->fetch_assoc();
?>




<?php 
$pembeliygbeli=$detail["usernamee"];

$pembeliyglogin= $_SESSION["pembeli"]["usernamee"];

if($pembeliygbeli!==$pembeliyglogin)
{
	echo "<script>location='riwayat.php';</script>";
	exit();
}
?>







<strong><?php echo $detail['nama'];?></strong><br> 
Id Faktur : <?php echo $detail['id_faktur'];?><br>

<?php 
$ambill= $koneksi->query("SELECT * FROM faktur JOIN pengiriman 
						ON faktur.id_ongkir=pengiriman.id_pengiriman 
						WHERE faktur.id_faktur='$_GET[id]'");
$detaill = $ambill->fetch_assoc();
?>
	Kota Tujuan = <?php echo $detaill["nama_kota"]; ?> <br>
<p>
	Tanggal	: <?php echo $detail['tanggal']; ?> <br>
</p>
<table class="table table-bordered" style="background-color:cornsilk;">
	<thead>
		<tr>
			<th> No </th>
			<th> Nama Barang </th>
			<th> Harga </th>
			<th> Jumlah Barang </th>
			<th> Sub Total </th>
		</tr>
	</thead>
	<tbody>
		<?php $nomor=1; ?>
		<?php $totalbelanja=0;?>
		<?php $ambil=$koneksi->query("SELECT * FROM transaksi JOIN parfum ON transaksi.id_parfum=parfum.id_parfum 
		WHERE transaksi.id_faktur='$_GET[id]'");?>
		<?php while($pecah=$ambil->fetch_assoc()){ ?>
		<tr>
			<td><?php echo $nomor; ?> </td>
			<td><?php echo $pecah['nama_barang']; ?> </td>
			<td><?php echo $pecah['harga']; ?></td>
			<td><?php echo $pecah['QTY']; ?></td>
			
			<td> 
				Rp. <?php echo number_format($pecah['harga']*$pecah['QTY']); ?> </td>
			</td>
		</tr>
		<?php $totalbelanja+=($pecah['harga']*$pecah['QTY']);?>
		<?php $nomor++ ?>
		<?php } ?>
	</tbody>
				<tfoot>
				<tr>
					<th colspan="4"> Total Belanja</th>
					<th>Rp.<?php echo number_format( $totalbelanja)?>
				</tr>
				<tr>
					<th colspan="4"> Biaya Pengiriman</th>
					<th>Rp.<?php echo number_format( $detaill["tarif"]); ?> 
				</tr>
				<tr>
					<th colspan="4"> Total Bayar</th>
					<th>Rp. <?php echo number_format($detail['total_bayar']);?></th>
				</tr>
			</tfoot>
</table>
	
	
	
	
	
<div class="row">
		<div class="col-md-7">
			<div class="alert alert-info">
				<p>
					<strong> Terima Kasih Telah Melakukan Pembayaran ! </strong>
				</p>
			</div>	
		</div>
</div>
	
	
	
	
	
	
	
	
	
	</div>
</section>


</body>
</html>