<h2>Tambah Produk</h2>

<form method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label>Nama</label>
        <input type="text" class="form-control" name="nama">
    </div>
    <div class="form-group">
		<label> Jenis </label>
		<select class="form-control" name="idjenis" required>
		<?php $ambil=$koneksi->query("SELECT*FROM jenis_parfum ");?>
		<?php while($pecah=$ambil->fetch_assoc()){?>
<option value="<?php echo $pecah['id_jenis'] ?>" > <?php echo $pecah['id_jenis'] ?>-<?php echo $pecah['nama_jenis'] ?></option>
<?php } ?>
</select>
<div class="form-group">
		<label> Merk </label>
		<select class="form-control" name="ijenis" required>
		<?php $ambil=$koneksi->query("SELECT*FROM merk_parfum ");?>
		<?php while($pecah=$ambil->fetch_assoc()){?>
<option value="<?php echo $pecah['id_merk'] ?>" > <?php echo $pecah['id_merk'] ?>-<?php echo $pecah['nama_merk'] ?></option>
<?php } ?>
</select>
<div class="form-group">
		<label> Ukuran </label>
		<select class="form-control" name="idukuran" required>
		<?php $ambil=$koneksi->query("SELECT*FROM ukuran_parfum ");?>
		<?php while($pecah=$ambil->fetch_assoc()){?>
<option value="<?php echo $pecah['id_ukuran'] ?>" > <?php echo $pecah['id_ukuran'] ?>-<?php echo $pecah['jenis_ukuran'] ?></option>
<?php } ?>
</select>
</div>
    <div class="form-group">
        <label>Harga (Rp. )</label>
        <input type="number" class="form-control" name="harga">
    </div>
    <div class="form-group">
        <label>Deskripsi</label>
        <textarea class="form-control" name="deskripsi" rows="10"></textarea>
    </div>
    <div class="form-group">
        <label>Foto</label>
        <input type="file" class="form-control" name="foto">
    </div>
    <div class="form-group">
        <label>Stok</label>
        <input type="number" class="form-control" name="stok">
    </div>
    <button class="btn btn-primary" name="save">Simpan</button>
</form>
<?php
if (isset($_POST['save']))
{
    $nama = $_FILES['foto']['name'];
    $lokasi =$_FILES['foto']['tmp_name'];
    move_uploaded_file($lokasi, "../foto_parfum/".$nama);
    $koneksi->query("INSERT INTO parfum
        (nama_parfum,id_jenis,id_merk,id_ukuran,harga,deskripsi,gambar_parfum,stok)
        VALUES('$_POST[nama]','$_POST[jenis]','$_POST[merk]','$_POST[ukuran]','$_POST[harga]',
        '$_POST[deskripsi]','$nama','$_POST[stok]')");
    echo "<div class='alert alert-info'>Data tersimpan</div>";
    echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=produk'>";
}
?>