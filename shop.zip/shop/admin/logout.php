<?php
session_destroy();
echo "<script>location='login.php';</script>";
echo "<script>location='login.php';</script>";
?>