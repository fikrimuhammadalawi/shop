﻿<?php
   session_start();
   if(isset($_SESSION['username'])) {
   header(''); }
   require_once("koneksi.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
<title>Login Admin</title>
<!--Stylesheet-->
<style media="screen">
*,
*:before,
*:after{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}
form{
    height: 520px;
    width: 400px;
    background-color: transparent;
    position: absolute;
    transform: translate(-50%,-50%);
    top: 50%;
    left: 50%;
    border-radius: 10px;
    backdrop-filter: blur(10px);
    border: 2px solid rgba(255,255,255,0.1);
    box-shadow: 0 0 40px rgba(8,7,16,0.6);
    padding: 50px 35px;
}
form *{
    font-family: 'Poppins',sans-serif;
    color: white;
    letter-spacing: 0.5px;
    outline: none;
    border: none;
}
form h3{
    color: white;
    font-size: 13px;
    font-weight: 500;
    line-height: 42px;
    text-align: center;
}
form select{
    color: black;
}
form option{
    color: black;
}
form a{
    color: blue;
}
form h5{
    text-align: Center;
    color: #fafafa;
    margin-bottom: 20px;
	font-size: 15px;
}
input{
    display: block;
    text-align: center;
    height: 50px;
    width: 100%;
    background-color: rgba(255,255,255,0.07);
    border-radius: 3px;
    padding: 0 10px;
    margin-top: 8px;
    font-size: 14px;
    font-weight: 300;
}
::placeholder{
    color: #e5e5e5;
}
button{
    margin-top: 50px;
    width: 100%;
    background-color: #1845ad;
    color: #ffffff;
    padding: 15px 0;
    font-size: 18px;
    font-weight: 600;
    border-radius: 5px;
    cursor: pointer;
    margin-bottom: 17px;
}

</style>
</head>

<BODY STYLE="BACKGROUND-IMAGE:URL(bg.png)">
<section class="popup-graybox">
<div class="ebook-popup-sec" >
<form role="form" method="post" action="proseslogin.php">
 <img src="images/bg.png" alt="">
  <center><h2 data-edit="text">Login Admin</h2></center>
  <h3 data-edit="text">Silahkan Masukkan Username dan Password Anda</h3>
  <div class="ebook-email-sec">
    <input autocomplete="off" name="username" type="text" class="ebookemail-input1" data-edit="placeholder" placeholder="Enter User Name" >
    <input name="password" type="password" class="ebookemail-input2" data-edit="placeholder" placeholder="Enter Password">
	<br>
Level : <select class="form-control" name="level" required>
<option value="" > Pilih Level </option>
<option value="admin"> Admin </option>
<option value="super admin"> Super Admin </option>
</select>
</br>
<BR>
    <button class="ebook-input-btn" type="submit" name="login">Login</button>
</BR>
  </div>
  <h5>Belum Terdaftar? <span><a href="daftaradmin.php"> Daftar disini </span> </h5>
</div>    
</section>
</body>
</html>
