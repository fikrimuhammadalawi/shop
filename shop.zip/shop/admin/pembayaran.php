<h2> Data Pembayaran </h2>
<?php
session_start();
$koneksi = new mysqli("localhost","root","","toko_parfume");
$ambil = $koneksi->query("SELECT * FROM faktur JOIN jenis_pembayaran
    ON faktur.id_jenisbayar=jenis_pembayaran.id_jenisbayar
    WHERE faktur.id_jenisbayar='$_GET[id]'");
$detail = $ambil->fetch_assoc();
?>

<div class="row">
	<div class="col-md-6"></div>
		<table class="table table-bodered">
			<tr>
				<td><center>Nama</center></td>
				<td><center>Id Faktur</center></td>
				<td><center>Jenis Bayar</center></td>
				<td><center>Jumlah</center></td>
				<td><center>Tanggal</center></td>
				<td><center>Bukti Pembayaran</center></td>
			</tr>			
			<tr>
				<td><?php echo $detail['nama_pembeli'];?></td>
				<td><?php echo $detail['id_faktur'];?></td>
				<td><?php echo $detail['keterangan'];?></td>
				<td><?php echo number_format($detail['jumlah']);?></td>
				<td><?php echo $detail['tgl_pembayaran'];?></td>
				<td><img src="/bukti_pembayaran/<?php echo $detail['bukti_pembayaran'];?>" width="200" class="img-responsive"></td>
			</tr>
		</table>
</div>
<form method="post">
	<div class = "form-group">
		<label> Status Pembelian </label>
		<select class="form-control" name="status">
			<option value="">Pilih Status</option>
			<option value="Barang Dikemas">Barang Dikemas</option>
			<option value="Barang Dikirim">Barang Dikirim</option>
			<option value="Batal">Batal</option>
		</select>
	</div>
		<button class="btn btn-primary" name="proses">Proses</button>
</form>
<?php

if(isset($_POST["proses"]))
{
	$status=$_POST["status"];
	$koneksi->query(" UPDATE faktur SET status_pembelian='$status' WHERE id_faktur='$id_faktur'");
	
	
	echo "<script>alert('Status Pembelian Diperbarui');</script>";
	echo "<script>location='index.php?halaman=faktur';</script>";
}

?>