<h2>Ukuran Produk</h2>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Id</th>
            <th>Nama</th>
        </tr>
    </thead>
    <tbody>
        <?php $nomor=1; ?>
        <?php $ambil=$koneksi->query("SELECT * FROM ukuran_parfum"); ?>
        <?php while($pecah = $ambil->fetch_assoc()){ ?>
        <tr>
            <td><?php echo $nomor; ?></td>
            <td><?php echo $pecah['id_ukuran']; ?></td>
            <td><?php echo $pecah['jenis_ukuran']; ?></td>
        <td>
                <a href ="index.php?halaman=hapusukuran&id=<?php echo $pecah['id_ukuran']; ?>" class="btn-danger btn">hapus</a>
                <a href ="index.php?halaman=ubahukuran&id=<?php echo $pecah['id_ukuran']; ?>" class="btn btn-warning">ubah</a>
         </td>
        </tr>
        <?php $nomor++; ?>
        <?php } ?>

    </tbody>
</table>
<a href="index.php?halaman=tambahukuran" class="btn btn-primary">Tambah Data</a>