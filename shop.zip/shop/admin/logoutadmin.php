<?php
session_destroy();
echo "<script>location='loginadmin.php';</script>";
echo "<script>location='loginadmin.php';</script>";
?>