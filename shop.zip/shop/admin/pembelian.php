<h2>Data Pembelian</h2>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Pelanggan</th>
            <th>Tanggal</th>
            <th>Bukti Pembayaran</th>
            <th>Total</th>
            <th>Status Pembelian</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $nomor=1; ?>
        <?php $ambil=$koneksi->query("SELECT * FROM faktur JOIN pembeli ON faktur.id_pembeli=pembeli.id_pembeli"); ?>
        <?php while($pecah = $ambil->fetch_assoc()){ ?>
        <tr>
            <td><?php echo $nomor; ?></td>
            <td><?php echo $pecah['nama']; ?></td>
            <td><?php echo $pecah['tgl_pembayaran']; ?></td>
            <td><?php echo $pecah['bukti_pembayaran']; ?></td>
            <td><?php echo $pecah['total_bayar']; ?></td>
            <td><?php echo $pecah['status_pembelian']; ?></td>
            <td>
                <a href="index.php?halaman=detail&id=<?php echo $pecah['id_faktur']; ?>" class="btn btn-info">detail</a>
            </td>
        </tr>
        <?php $nomor++; ?>
        <?php } ?>
    </tbody>
</table>