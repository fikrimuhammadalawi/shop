<?php
session_start();
$koneksi = new mysqli("localhost","root","","toko_parfume");
?>
<html>
<head>
<title> Home </title>
</head>
<body style = "background-color:#696969">
<h1><center>Selamat Datang di Website Toko Parfum</h1></center>
<div><h3><center>Kunjungi Toko Kami Segeraa !!!</h3></center></div>
<h4><center>Anda Admin? <a href="loginadmin.php"> Login Disini </a></center></h4>
</body>

</html>