<?php
session_start();
$koneksi = new mysqli("localhost","root","","toko_parfume");
?>
<html>
<head>
<title> Home </title>
</head>
<body STYLE="BACKGROUND-color: #ccc">
<h2>Selamat Datang di Website Toko Parfum</h2>
<h4>Kunjungi Toko Kami Segeraa !!!</h4>
<h5> Anda Admin? <a href="loginakun.php"> Login Disini </a> </h5>
</body>

</html>