<h2>Detail Pembelian</h2>
<?php
$ambil = $koneksi->query("SELECT * FROM faktur JOIN pembeli 
                            ON faktur.id_pembeli=pembeli.id_pembeli 
                            WHERE faktur.id_faktur='$_GET[id]'");
$detail = $ambil->fetch_assoc();
?>
<pre><?php print_r($detail); ?></pre>

<strong><?php echo $detail['nama']; ?></strong><br>
<p>
    <?php echo $detail['no_tlp']; ?> <br>
    <?php echo $detail['email']; ?> <br>
</p>

<p>
    Tanggal : <?php echo $detail['tgl_pembayaran']; ?> <br>
    Total : <?php echo $detail['total_bayar']; ?> <br>
</p>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
        </tr>
    </thead>
    <tbody>
        <?php $nomor=1; ?>
        <?php $ambil=$koneksi->query("SELECT * FROM transaksi JOIN parfum ON transaksi.id_parfum=parfum.id_parfum WHERE transaksi.id_faktur='$_GET[id]'"); ?>
        <?php while($pecah=$ambil->fetch_assoc()){ ?>
        <tr>
            <td><?php echo $nomor; ?></td>
            <td><?php echo $pecah['nama_parfum']; ?></td>
            <td><?php echo $pecah['harga']; ?></td> 
            <td><?php echo $pecah['QTY']; ?></td>
            <td>
                <?php echo $pecah['harga']*$pecah['QTY'] ?>
            </td>
        </tr>
        <?php $nomor++; ?> 
        <?php } ?>
    </tbody>
</table>