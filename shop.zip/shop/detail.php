<?php
   session_start();
   if(isset($_SESSION['id_pembeli'])) {
   header(''); }
   require_once("koneksi.php");
   
$ambildata= $koneksi->query("SELECT * FROM parfum JOIN merk_parfum 
ON parfum.id_merk=merk_parfum.id_merk JOIN ukuran_parfum 
ON parfum.id_ukuran=ukuran_parfum.id_ukuran JOIN jenis_parfum 
ON parfum.id_jenis=jenis_parfum.id_jenis");
$detail = $ambildata->fetch_assoc();

?>
 <!DOCTYPE html>
 <html>
 <head>
	<title> Detail Produk </title>
	<link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>
<BODY STYLE="BACKGROUND-IMAGE:URL(detail.png)">

<?php include 'menu.php'?>

<section class="konten">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
			<img src="/foto_produk/<?php echo $detail["foto_produk"];?>" class="img-responsive" >
			</div>
			<div class="col-md-6">
				<h2><?php echo $detail["nama_parfum"];?></h2>
				<h4> Harga : <?php echo number_format($detail["harga"]);?>/<?php echo $detail['deskripsi']?></h4>
				<h5> Stok : <?php echo $detail["stok"];?></h5>
			<form method="post">
				<div class="form-group">
					<div class="input-group">
						<input type="number" min="1" class="form-control" name="jumlah" max="<?php echo $detail["stok"]?>">
						<div class="input-group-btn">
							<button class="btn btn-primary" name="beli">Beli</button>
						</div>
					</div>
				</div>
			</form>
			
			<?php 
			
			if (isset($_POST["beli"]))
			{
				$jumlah =$_POST["jumlah"];
				//masukkan dikeranjang
				$_SESSION["keranjang"][$id_parfum]=$jumlah;
				
				echo "<script>alert('Produk telah masuk ke keranjang belanja');</script>";
				echo "<script>location='keranjang.php';</script>";
			}
			
			
			
			
			
			
			?>
			</div>
		</div>
	</div>
</section>

</body>
 </html>