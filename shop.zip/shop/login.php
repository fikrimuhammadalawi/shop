<?php
   session_start();
   if(isset($_SESSION['id_pembeli'])) {
   header(''); }
   require_once("admin/koneksi.php");
?>
<!doctype html>
<html>
<head>
<title>Login Pembeli</title>
<style>
*{
    margin: 0;
    padding: 0;
    outline: 0;
    font-family: 'PT Serif';
}
body{
    height: 100vh;
    background-image: url();
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}

.container{
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    padding: 20px 25px;
    width: 300px;

    background-color: rgba(0,0,0,.7);
    box-shadow: 0 0 10px rgba(255,255,255,.3);
}
.container h2{
    text-align: Center;
	border: none;
    color: #fafafa;
	border-bottom: 3px solid #2979ff;
    margin-bottom: 40px;
}
.container h4{
    text-align: Center;
    color: #fafafa;
    margin-bottom: 30px;
}
.container input{
	text-align: Center;
    margin-bottom: 30px;
}
.container h5{
    text-align: Center;
    color: #fafafa;
    margin-bottom: 20px;
	font-size: 15px;
}
.container label{
    text-align: left;
    color: #90caf9;
}
.container form input{
    width: calc(100% - 20px);
    padding: 8px 10px;
    margin-bottom: 10px;
    border: none;
    background-color: transparent;
    border-bottom: 2px solid #2979ff;
    color: #fff;
    font-size: 20px;
}
.container form button{
    width: 100%;
    padding: 5px 0;
    border: none;
    background-color:#2979ff;
    font-size: 18px;
    color: #fafafa;
	margin-bottom: 20px;
}
</style>
</head>

<BODY STYLE="BACKGROUND-IMAGE:URL(admin/bg.png)">
<section class="popup-graybox">
<div class="container" >
<form role="form"  method="post">
 <img src="images/login02_popup.png" alt="">
  <h2 data-edit="text">LOGIN</h2>
  <div class="ebook-email-sec">
    <input autocomplete="off" name="email" type="email" class="ebookemail-input1" data-edit="placeholder" placeholder="Enter Email">
    <input name="pass" type="password" class="ebookemail-input2" data-edit="placeholder" placeholder="Enter Password">
<BR>
    <button class="ebook-input-btn" type="submit" name="login">Login</button>
</BR>
  </div>
  <div>
  <h5>Belum Terdaftar? <span><a href="daftar.php"> Daftar Disini </span> </h5>
</div>    
</section>
</form>

<?php


//jk ada tombol login(login) ditekan
if(isset($_POST["login"]))
{
	
	$nama = $_POST["email"];
	$password = $_POST["pass"];
	
	//lakukan query ngecek akun di tabel pembeli di db
	$ambil= $koneksi->query ("SELECT * FROM pembeli WHERE email='$nama' AND pass='$password'");
	
	//itung akun yg terambil
	$akunyangcocok=$ambil->num_rows;
	
	//jika 1 akun yg cocok, maka diloginkan
	if($akunyangcocok==1)
	{
		//sukses  login
		$akun = $ambil->fetch_assoc();
		$_SESSION["pembeli"]=$akun;
		echo "<script> alert('Login Berhasil');</script>";
		
		//jk sdh belanja
		if(isset($_SESSION["keranjang"]) OR !empty($_SESSION["keranjang"]))
		{
			echo "<script> location='checkout.php';</script>";
		}
		else
		{
			echo "<script> location='index.php';</script>";	
		}
	}
	else
	{
		//gagal login
		echo "<script> alert('anda gagal login, periksa kembali data Anda');</script>";
		echo "<script> location ='login.php';</script>";
	}
}

?>
</body>
</html>
