<?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "toko_parfume";

$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
?>
<?php
$keyword= $_GET["keyword"];

$semuadata=array();
$ambil=$koneksi->query("SELECT *FROM parfum WHERE nama_parfum LIKE '%$keyword%' 
				  ORDER BY parfum.nama_parfum ASC");
while($pecah=$ambil->fetch_assoc())
{
	$semuadata[]=$pecah;
}	

?>

<!DOCTYPE html>
<html>
<head>
	<title>Pencarian</title>
	<link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>
<BODY STYLE="BACKGROUND-IMAGE:URL(pencarian.JPG)">
<?php include 'menu.php'?>
	<div class="container">
		
		<?php if(empty($semuadata)):?>
			<div class="alert alert-danger">Produk <strong><?php echo $keyword?></strong> tidak ditemukan</div>
		<?php endif?>
		
		
		<div class="row">
		
		
			<?php foreach ($semuadata as $key =>$value):?>
			
			<div class="col-md-3">
				<div class="thumbnail">
					<img src="foto_produk/<?php echo $value["gambar_parfum"]?>" alt="" class="img-responsive">
					<div class="caption">
						<h3><?php echo $value["nama_parfum"];?></h3>
						<h5><?php echo number_format($value['harga'])?></h5>
						<a href="beli.php?id=<?php echo $value["id_parfum"];?>" class="btn btn-primary">Beli</a>
						<a href="detail.php?id=<?php echo $value["id_parfum"];?>" class="btn btn-default">Detail</a>
					</div>
				</div>
			</div>
			<?php endforeach?>
			
		</div>
	</div>
</body>
</html>