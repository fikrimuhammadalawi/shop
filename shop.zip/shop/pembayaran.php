<?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "toko_parfume";

$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
session_start();

$idpem= $_GET["id"];
$ambil=$koneksi->query("SELECT *FROM faktur WHERE id_faktur='$idpem'");
$detpem=$ambil->fetch_assoc();

$idpemygbeli=$detpem["id_pembeli"];
$idpemyglogin=$_SESSION["pembeli"]["id_pembeli"];
if ($idpemyglogin!==$idpemygbeli)
{
	echo "<script>alert('Tidak dapat diproses ');</script>";
	echo "<script>location='riwayat.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title> Pembayaran </title>
	<link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>
<BODY STYLE="BACKGROUND-IMAGE:URL(pembayaran.JPG)">

<?php include 'menu.php'?>

<div class="container">
	<h2>Konfirmasi Pembayaran</h2>
	<p>Kirim bukti pembayaran anda disini</p>
	<div class="alert alert-info"> Total yang harus dibayarkan : <strong> 
	Rp. <?php echo number_format($detpem["total_bayar"])?></strong></div>
	
	
	<form method="post" enctype="multipart/form-data">
		<div class="form-group">
			<label> Bank </label>
			<input autocomplete="off" type="text" class="form-control" name="bank">
		</div>
		<div class="form-group">
			<label> Bukti Pembayaran </label>
			<input  type="file" class="form-control" name="bukti">
			<p class="text-danger"> Foto bukti harus .JPG maks.2MB </p>
		</div>
		<button class="btn btn-primary" name="kirim"> Kirim</button>
	</form>
</div>



<?php

//jk tombol kirim diklik
if(isset($_POST["kirim"]))
{
	//uploadfotobukti
	$namabukti=$_FILES["bukti"]["name"];
	$lokasibukti=$_FILES["bukti"]["tmp_name"];
	$namafiks=date("YmdHis").$namabukti;
	move_uploaded_file($lokasibukti,"bukti_pembayaran/$namafiks");
	

	$bank =$_POST["bank"];
	$tanggal=date("Y-m-d");
	
		$koneksi->query("UPDATE faktur SET bank='$bank', bukti_pembayaran='$namafiks',tgll_pembayaran='$tanggal'
		WHERE id_faktur='$idpem'");			
	//update status pembayaran
	$koneksi->query("UPDATE faktur SET status_pembelian='Sudah Kirim Pembayaran' WHERE id_faktur='$idpem'");
	
		echo "<script>alert('Terimakasih sudah melakukan pembayaran ');</script>";
	echo "<script>location='riwayat.php';</script>";
}



?>


</body>
</html>