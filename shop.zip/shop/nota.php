<?php
   session_start();
   if(isset($_SESSION['id_pembeli'])) {
   header(''); }
   require_once("admin/koneksi.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Nota pembelian</title>
    <link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>
<body>

<?php include 'menu.php'; ?>

<section class="konten">
    <div class="container">



    <!-- nota disini copas saja dari nota yang ada di admin -->
    <h2>Detail Faktur</h2>
<?php
$ambil = $koneksi->query("SELECT * FROM faktur JOIN pembeli
    ON faktur.id_pembeli=pembeli.id_pembeli
    WHERE faktur.id_pembeli='$_GET[id]'");
$detail = $ambil->fetch_assoc();
?>



<!-- jika pembeli yg tidak sama dengan pembeli yg login, maka dilarikan ke riwayat.php karena di tidak berhak melihat nota orang lain-->
<!-- pembeli yg beli harus pembeli yg login-->
<?php
// mendapatkan id_pembeli yg login
$idpembeliyangbeli = $detail["id_pembeli"];

// mendapatkan id_pembeli yg login
$idpembeliyanglogin = $_SESSION["pembeli"]["id_pembeli"];

if ($idpembeliyangbeli!==$idpembeliyanglogin)
{
    echo "<script>location='riwayat.php';</script>";
    exit();
}
?>

<div class="row">
    <div class="col-md-4">
        <h3>Faktur</h3>
        <strong>No. Faktur: <?php echo $detail['id_faktur'] ?></strong><br>
        Tanggal: <?php echo $detail['tgl_pembayaran']; ?><br>
        Total: Rp. <?php echo number_format($detail['total_bayar']) ?>
    </div>
    <div class="col-md-4">
       <h3>Pembeli</h3>
       <strong><?php echo $detail['nama_pembeli']; ?></strong> <br>
       <p>
            <?php echo $detail['tlp_pembeli']; ?> <br>
            <?php echo $detail['email']; ?>
        </p>
    </div>
    <div class="col-md-4">
        <h3>Pengiriman</h3>
        <strong><?php echo $detail['nama_kota'] ?></strong><br>
        Ongkos Kirim: Rp. <?php echo number_format($detail['ongkir']); ?><br>
        Alamat: <?php echo $ddetail['alamat_pengiriman'] ?>
    </div>
</div>

<table class="table table-bordered">
    <thread>
        <tr>
            <th>no</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
        </tr>
    </thread>
    <tbody>
        <?php $nomor=1; ?>
        <?php $ambil=$koneksi->query("SELECT * FROM faktur WHERE id_faktur='$_GET[id]'") ?>
        <?php while($pecah=$ambil->fetch_assoc()){ ?>
        <tr>
            <td><?php echo $nomor; ?></td>
            <td><?php echo $pecah['nama']; ?></td>
            <td>Rp. <?php echo number_format($pecah['harga']); ?></td>
            <td><?php echo $pecah['jumlah']; ?></td>
            <td>Rp. <?php echo number_format($pecah['subharga']) ?></td>
        </tr>
        <?php $nomor++; ?>
        <?php } ?>
    </tbody>
</table>